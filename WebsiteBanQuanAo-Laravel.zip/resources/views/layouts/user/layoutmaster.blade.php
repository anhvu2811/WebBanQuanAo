<!DOCTYPE html>
<html lang="vi">
<body>
    @include('layouts/user/header')

    @yield('content')

    @include('layouts/user/footer')
</body>
</html>
