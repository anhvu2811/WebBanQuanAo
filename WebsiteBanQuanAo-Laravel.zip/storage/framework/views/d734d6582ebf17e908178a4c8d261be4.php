<!-- resources/views/order/index.blade.php -->
<?php 
    use Carbon\Carbon;
?>

<?php $__env->startSection('title', 'Danh sách đơn hàng'); ?>
<?php $__env->startSection('content'); ?>
    <h2 style="text-align: center; padding: 20px;">Danh sách đơn hàng</h2>
    <button><a href="/order/create">Add</a></button>

    <form method="GET" action="<?php echo e(route('order.index')); ?>">
        <label for="perPage">Chọn số hiển thị:</label>
        <select name="perPage" id="perPage" onchange="this.form.submit()">
            <option value="10" <?php echo e(request('perPage') == 10 ? 'selected' : ''); ?>>10</option>
            <option value="20" <?php echo e(request('perPage') == 20 ? 'selected' : ''); ?>>20</option>
            <option value="30" <?php echo e(request('perPage') == 30 ? 'selected' : ''); ?>>30</option>
        </select>
    </form>

    <table class="table table-striped table-bordered" style="text-align: center;">
        <thead class="thead-dark">
            <tr>
                <th>Order date</th>
                <th>Customer name</th>
                <th>Total price</th>
                <th colspan="2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <button>
                            <?php echo e(Carbon::parse($order->order_date)->format('d/m/Y')); ?> <br>
                            <?php echo e(Carbon::parse($order->order_date)->format('H:i:s')); ?>

                        </button>
                    </td>
                    
                    <td><?php echo e($order->customer_name); ?></td>
                    <td><?php echo e(number_format($order->total_price, 0, ',', '.')); ?></td>
                    <td>
                        <button>Detail</button>
                    </td>
                    <td>
                        <form action="<?php echo e(route('order.destroy', ['id' => $order->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Are you sure you want to delete this order?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Liên kết phân trang -->
    <div style="text-align: center;">
        <?php echo e($orders->appends(request()->query())->links('pagination::bootstrap-4')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/order/index.blade.php ENDPATH**/ ?>