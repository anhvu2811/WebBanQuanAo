<!DOCTYPE html>
<html lang="vi">
<body>
    <?php echo $__env->make('layouts/user/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts/user/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/layouts/user/index.blade.php ENDPATH**/ ?>