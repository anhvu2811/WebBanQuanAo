<!-- resources/views/categories/index.blade.php -->


<?php $__env->startSection('title', 'Cài đặt'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Setting</h1>
    <form action="<?php echo e(route('setting.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="adddress">Địa chỉ:</label><br>
        <input type="text" id="adddress" name="adddress" placeholder="Enter adddress" value="<?php echo e($setting->location ?? ''); ?>" required><br><br>

        <label for="hotline">Hotline:</label><br>
        <input type="text" id="hotline" name="hotline" placeholder="Enter hotline" value="<?php echo e($setting->hotline ?? ''); ?>" required><br><br>
        
        <label for="email">Email:</label><br>
        <input type="text" id="email" name="email" placeholder="Enter email" value="<?php echo e($setting->email ?? ''); ?>" required><br><br>
        
        <label for="logo">Logo:</label><br>
        <input type="file" id="logo" name="logo" placeholder="Enter logo" ><br><br>

        <label for="time_active">Thời gian hoạt động:</label><br>
        <input type="text" id="time_active" name="time_active" placeholder="Enter time active" value="<?php echo e($setting->time_active ?? ''); ?>" required><br><br>

        <label for="site_name">Tên trang web:</label><br>
        <input type="text" id="site_name" name="site_name" placeholder="Enter site name" value="<?php echo e($setting->site_name ?? ''); ?>" required><br><br>

        <label for="site_description">Mô tả trang web:</label><br>
        <input type="text" id="site_description" name="site_description" placeholder="Enter site description" value="<?php echo e($setting->site_description ?? ''); ?>" required><br><br>

        <button type="submit">Save</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/setting/index.blade.php ENDPATH**/ ?>