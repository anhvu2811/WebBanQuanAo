<?php $__env->startSection('title', 'Danh sách sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <h2 style="text-align: center; padding: 20px;"  >Danh sách sản phẩm</h2>
    <button><a href="/product/create">Add</a></button>

    <form method="GET" action="<?php echo e(route('product.index')); ?>">
        <label for="perPage">Chọn số hiển thị:</label>
        <select name="perPage" id="perPage" onchange="this.form.submit()">
            <option value="10" <?php echo e(request('perPage') == 10 ? 'selected' : ''); ?>>10</option>
            <option value="20" <?php echo e(request('perPage') == 20 ? 'selected' : ''); ?>>20</option>
            <option value="30" <?php echo e(request('perPage') == 30 ? 'selected' : ''); ?>>30</option>
        </select>

        <label for="search">Tìm kiếm tên sản phẩm:</label>
        <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>" placeholder="Nhập tên sản phẩm" />
        <button type="submit">Search</button>

        <label for="sortPrice">Sắp xếp theo tiền</label>
        <select name="sortPrice" id="sortPrice" onchange="this.form.submit()">
            <option value="asc" <?php echo e(request('sortPrice') == 'asc' ? 'selected' : ''); ?>>Giá tăng dần</option>
            <option value="desc" <?php echo e(request('sortPrice') == 'desc' ? 'selected' : ''); ?>>Giá giảm dần</option>
        </select>
    </form>

    <!-- Hiển thị danh sách sản phẩm -->
    <div id="productList">
        <?php echo $__env->make('product.product_table', ['products' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Hiển thị phân trang -->
    <div id="pagination">
        <?php echo $__env->make('product.pagination', ['products' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\WebsiteBanQuanAo-Laravel\resources\views/product/index.blade.php ENDPATH**/ ?>