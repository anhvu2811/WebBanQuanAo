
<?php $__env->startSection('content'); ?>
<head>
   <title> <?php echo e($setting->site_name ?? 'NULL'); ?> - Giỏ Hàng </title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   <style>
      .box-heading {
         margin-bottom: 30px;
         margin-top: 30px;
      }

      table {
         width: 100%;
         border-collapse: collapse;
         margin: 20px 0;
      }

      table th, table td {
         padding: 15px;
         text-align: left;
         border-bottom: 1px solid #ddd;
      }

      table th {
         background-color: #f7f7f7;
         color: #333;
      }

      table td img {
         width: 80px;
         height: 80px;
         object-fit: cover;
      }

      table td.product-name {
         font-weight: bold;
      }

      table td.price, table td.quantity, table td.total {
         text-align: center;
      }

      /* Cart summary styles */
      .cart-summary {
         background-color: #fff;
         padding: 20px;
         box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
         margin-top: 30px;
         display: flex;
         justify-content: space-between;
      }

      .cart-summary .total {
         font-size: 24px;
         font-weight: bold;
         color: #333;
      }

      .cart-summary .checkout-button {
         background-color: #007bff;
         color: #fff;
         padding: 12px 20px;
         border: none;
         cursor: pointer;
         font-size: 18px;
         border-radius: 5px;
         text-align: center;
      }

      .cart-summary .checkout-button:hover {
         background-color: #0056b3;
      }

      /* Responsive design */
      @media (max-width: 768px) {
         .container {
            padding: 10px;
         }

         table th, table td {
            padding: 10px;
         }

         .cart-summary {
            flex-direction: column;
            align-items: center;
         }

         .cart-summary .total {
            margin-bottom: 15px;
         }
      }

   </style>
</head>
<div>
   <div class="container">
      <div class="box-heading">
         <h1 class="title-head page-title">Giỏ hàng</h1>
         <?php if(session('cart')): ?>
            <section style="background-color: white;">
               <table>
                  <thead>
                     <tr>
                        <th>Hình ảnh</th>
                        <th>Tên sản phẩm</th>
                        <th>Giá</th>
                        <th>Số lượng</th>
                        <th>Tổng</th>
                        <th>Thao tác</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                        $total = 0;
                     ?>
                     <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                           <td><img src="<?php echo e(asset('storage/' . $cart['image'])); ?>" alt="<?php echo e($cart['name']); ?>" width="100"></td>
                           <td><?php echo e($cart['name']); ?></td>
                           <td><?php echo e(number_format($cart['price'], 0, ',', '.')); ?>₫</td>
                           <td>
                              <input type="number" value="<?php echo e($cart['quantity']); ?>" min="1" max="10" />
                           </td>
                           <td>
                              <?php
                                 $itemTotal = $cart['quantity'] * $cart['price'];
                                 $total += $itemTotal;
                              ?>
                              <?php echo e(number_format($itemTotal , 0, ',', '.')); ?>₫
                           </td>
                           <td>
                              <form action="<?php echo e(route('cart.remove', $id)); ?>" method="POST">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('DELETE'); ?>
                                 <button type="submit" class="btn btn-danger" style="border: none; background: none;">
                                    <i class="fa fa-times" style="font-size: 20px; color: #e8b34f; font-weight: bold;"></i>
                                </button>                                
                              </form>
                           </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
               </table>
            </section>

            <div class="cart-summary">
               <div class="total" style="margin-top: 10px">Tổng tiền: <span style="color: #e8b34f"><?php echo e(number_format($total , 0, ',', '.')); ?>₫</span></div>
               <a href="<?php echo e(route('cart.checkout')); ?>">
                  <button class="checkout-button" style="background-color: #e8b34f; color: #fff; border-radius: 3px; height: 50px; line-height: 35px; padding: 0 50px; font-size: 16px;">
                      Tiến hành thanh toán
                  </button>
              </a>
            </div>
         <?php else: ?>
            <p>Không có sản phẩm nào trong giỏ hàng. Quay lại cửa hàng để tiếp tục mua sắm.</p>
         <?php endif; ?>
      </div>
   </div>
   <?php echo $__env->make('page/list_brands', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/user/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/page/cart.blade.php ENDPATH**/ ?>