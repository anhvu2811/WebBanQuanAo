<h1>Create New Category</h1>
    <form action="<?php echo e(route('category.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="name">Tên loại:</label><br>
        <input type="text" id="name" name="name" placeholder="Enter category name" required><br><br>

        <label for="price">Mô tả:</label><br>
        <input type="text" id="price" name="description" placeholder="Enter description" required><br><br>

        <button type="submit">Create Category</button>
    </form>
<?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/category/create.blade.php ENDPATH**/ ?>