<div style="text-align: center;">
    <?php echo e($products->appends(request()->query())->links('pagination::bootstrap-4')); ?>

</div><?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/product/pagination.blade.php ENDPATH**/ ?>