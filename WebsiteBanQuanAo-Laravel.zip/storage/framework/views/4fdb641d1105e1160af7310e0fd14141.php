<?php $__env->startSection('title', 'Danh sách loại sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <h2 style="text-align: center; padding: 20px;">Danh sách loại sản phẩm</h2>
    <button><a href="/category/create">Add</a></button>

    <form method="GET" action="<?php echo e(route('category.index')); ?>">
        <label for="perPage">Chọn số hiển thị:</label>
        <select name="perPage" id="perPage" onchange="this.form.submit()">
            <option value="10" <?php echo e(request('perPage') == 10 ? 'selected' : ''); ?>>10</option>
            <option value="20" <?php echo e(request('perPage') == 20 ? 'selected' : ''); ?>>20</option>
            <option value="30" <?php echo e(request('perPage') == 30 ? 'selected' : ''); ?>>30</option>
        </select>
    </form>

    <table class="table table-striped table-bordered" style="text-align: center;">
        <thead class="thead-dark">
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Created at</th>
                <th colspan="2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $danhsachloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ds->name); ?></td>
                    <td><?php echo e($ds->description); ?></td>
                    <td><?php echo e($ds->created_at->format('d/m/Y H:i:s')); ?></td>
                    <td><a href="<?php echo e(route('category.edit', ['id' => $ds->id])); ?>">Update</a></td>
                    <td>
                        <form action="<?php echo e(route('category.destroy', ['id' => $ds->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Are you sure you want to delete this category?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Liên kết phân trang -->
    <div style="text-align: center;">
        <?php echo e($danhsachloai->appends(request()->query())->links('pagination::bootstrap-4')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/category/index.blade.php ENDPATH**/ ?>