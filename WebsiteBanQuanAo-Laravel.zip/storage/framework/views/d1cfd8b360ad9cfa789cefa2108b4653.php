
<?php $__env->startSection('title', 'Cài đặt'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Banner</h1>
    <form action="<?php echo e(route('banner.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <img src="<?php echo e(asset('storage/' .$mainBanner->banner_url)); ?>" height="100" width="100"/>
        <input type="file" id="" name="file" placeholder="Enter location"><br><br>

        <?php $__currentLoopData = $subBanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <img src="<?php echo e(asset('storage/' .$subBanner->banner_url)); ?>" height="100" width="100"/>
            <input type="file" id="" name="file" placeholder="Enter location"><br><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="submit">Save</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/banner/update.blade.php ENDPATH**/ ?>