<h1>Update Category</h1>
<form action="<?php echo e(route('category.update', ['id' => $category->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="name">Tên loại:</label><br>
    <input type="text" id="name" name="name" placeholder="Enter category name" value="<?= $category->name ?>" required><br><br>

    <label for="price">Mô tả:</label><br>
    <input type="text" id="price" name="description" placeholder="Enter description" value="<?= $category->description ?>" required><br><br>

    <button type="submit">Update Category</button>
</form>
<?php /**PATH D:\XAMPP\htdocs\WebBanHang-Laravel\resources\views/category/update.blade.php ENDPATH**/ ?>